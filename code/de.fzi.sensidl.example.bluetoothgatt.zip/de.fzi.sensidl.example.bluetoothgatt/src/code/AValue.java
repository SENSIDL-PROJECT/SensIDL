import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import com.google.gson.Gson;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
 
/**
 * Data transfer object for AValue
 *
 * @generated
 */
public class AValue {
	
	private static final long serialVersionUID = 1L;
	
	/*
	 * The Handler of the Attribute "Char_Value"" Length: 2 octets. Part of Attribute Value array*
	 */
	private java.lang.Short valueHandle;
	
	/*
	 * UUID of the specific characteristic Length: 2 or 16 octet. *
	 */
	private java.lang.Long uuid;
	
	/*	
	 * 
	 */
	private Properties properties;
	
	/**
	 * Constructor for the Data transfer object
	 */
	public AValue(java.lang.Short valueHandle, java.lang.Long uuid, Properties properties) {
		this.valueHandle = (short) (valueHandle - java.lang.Short.MAX_VALUE);
		this.uuid = (long) (uuid - java.lang.Long.MAX_VALUE);
		this.properties = properties;
	}
	
	/**
	 * empty constructor for the Data transfer object
	 */
	public AValue() {
	
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the valueHandle
	 */
	public java.lang.Short getValueHandle() {
		return (short) (this.valueHandle + java.lang.Short.MAX_VALUE);
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @param valueHandle
	 *            the valueHandle to set
	 */
	public void setValueHandle(java.lang.Short valueHandle){
		this.valueHandle = (short) (valueHandle - java.lang.Short.MAX_VALUE);
	} 
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the uuid
	 */
	public java.lang.Long getUuid() {
		return (long) (this.uuid + java.lang.Long.MAX_VALUE);
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @param uuid
	 *            the uuid to set
	 */
	public void setUuid(java.lang.Long uuid){
		this.uuid = (long) (uuid - java.lang.Long.MAX_VALUE);
	} 
	
	/**
	 * @return the properties
	 *
	 */
	public Properties getProperties() {
		return this.properties;
	}
	
	/**
	 * @param info
	 *            the properties to set
	 */
	public void setProperties(Properties properties) {
		this.properties = properties;
	}
	
	/**
	 * Alternative method responsible for deserializing the received
	 * JSON-formatted L stage from sensor.
	 * 
	 * @param dataset
	 *            the dataset to unmarshall incoming from sensor side in a JSON
	 *            format
	 * @return L unmarshalled L structure
	 */
	public AValue unmarshalAValueJSON(BufferedReader dataset) { 
		
		Gson gson = new Gson();
		BufferedReader br = dataset;
		AValue obj = gson.fromJson(br, AValue.class);
		// use little endianness 
		obj.convertAllToLittleEndian();
		return obj;
	}
	
	/**
	 * Alternative method responsible for serializing JSON
	 * 
	 * @return Json String
	 */
	public String marshalAValueJSON() { 
		Gson gson = new Gson();
		// use little endianness
		AValue aValue = new AValue(Gatt_CharacteristicUtility.convertToLittleEndian((short) (this.valueHandle + java.lang.Short.MAX_VALUE)), Gatt_CharacteristicUtility.convertToLittleEndian((long) (this.uuid + java.lang.Long.MAX_VALUE)) , convertToLittleEndian(this.properties));
		return gson.toJson(aValue);
	}
	
	/**
	 * Method responsible for deserializing the received byte array
	 * representation of L from sensor.
	 * 
	 * @param dataset
	 *            the dataset to unmarshall incoming from sensor side as a byte
	 *            array
	 * @return L unmarshalled L structure
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public AValue unmarshalAValueByteArray(byte[] dataset) throws IOException, ClassNotFoundException {
		
		ByteArrayInputStream in = new ByteArrayInputStream(dataset);
		ObjectInputStream ois = null;
		ois = new ObjectInputStream(in);
		Object o = ois.readObject();
		AValue aValue = (AValue) o; // TODO: Ensure the type conversion is valid
		in.close();
		if (in != null) {
			ois.close();
		}
		return aValue;
	}
	
	/**
	 * Method responsible for serializing Byte-Array
	 */
	public AValue marshalAValueByteArray() {
		//TODO: implement Method
		return null;
	}
	
	/**
	 * Converts a big endian Properties Object into a little endian Properties Object
	 *	
	 * @param the Properties Object to convert
	 * @return Properties the converted Properties Object
	 *
	 */
	public Properties convertToLittleEndian(Properties properties){
		//TODO: implement Method
		return null;
	}
	
	public void convertAllToLittleEndian(){
		valueHandle = Gatt_CharacteristicUtility.convertToLittleEndian(valueHandle);
		uuid = Gatt_CharacteristicUtility.convertToLittleEndian(uuid);
		properties = convertToLittleEndian(properties);
	}
	
	
}
