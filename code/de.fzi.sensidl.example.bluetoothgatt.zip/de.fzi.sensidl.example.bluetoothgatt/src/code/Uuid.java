import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import com.google.gson.Gson;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
 
/**
 * Data transfer object for Uuid
 *
 * @generated
 */
public class Uuid {
	
	private static final long serialVersionUID = 1L;
	
	private java.lang.Short uuid;
	
	private java.lang.Long bleUuid;
	
	/**
	 * Constructor for the Data transfer object
	 */
	public Uuid(java.lang.Short uuid, java.lang.Long bleUuid) {
		this.uuid = (short) (uuid - java.lang.Short.MAX_VALUE);
		this.bleUuid = (long) (bleUuid - java.lang.Long.MAX_VALUE);
	}
	
	/**
	 * empty constructor for the Data transfer object
	 */
	public Uuid() {
	
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the uuid
	 */
	public java.lang.Short getUuid() {
		return (short) (this.uuid + java.lang.Short.MAX_VALUE);
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @param uuid
	 *            the uuid to set
	 */
	public void setUuid(java.lang.Short uuid){
		this.uuid = (short) (uuid - java.lang.Short.MAX_VALUE);
	} 
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the bleUuid
	 */
	public java.lang.Long getBleUuid() {
		return (long) (this.bleUuid + java.lang.Long.MAX_VALUE);
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @param bleUuid
	 *            the bleUuid to set
	 */
	public void setBleUuid(java.lang.Long bleUuid){
		this.bleUuid = (long) (bleUuid - java.lang.Long.MAX_VALUE);
	} 
	
	/**
	 * Alternative method responsible for deserializing the received
	 * JSON-formatted L stage from sensor.
	 * 
	 * @param dataset
	 *            the dataset to unmarshall incoming from sensor side in a JSON
	 *            format
	 * @return L unmarshalled L structure
	 */
	public Uuid unmarshalUuidJSON(BufferedReader dataset) { 
		
		Gson gson = new Gson();
		BufferedReader br = dataset;
		Uuid obj = gson.fromJson(br, Uuid.class);
		// use little endianness 
		obj.convertAllToLittleEndian();
		return obj;
	}
	
	/**
	 * Alternative method responsible for serializing JSON
	 * 
	 * @return Json String
	 */
	public String marshalUuidJSON() { 
		Gson gson = new Gson();
		// use little endianness
		Uuid uuid = new Uuid(Gatt_CharacteristicUtility.convertToLittleEndian((short) (this.uuid + java.lang.Short.MAX_VALUE)), Gatt_CharacteristicUtility.convertToLittleEndian((long) (this.bleUuid + java.lang.Long.MAX_VALUE)) );
		return gson.toJson(uuid);
	}
	
	/**
	 * Method responsible for deserializing the received byte array
	 * representation of L from sensor.
	 * 
	 * @param dataset
	 *            the dataset to unmarshall incoming from sensor side as a byte
	 *            array
	 * @return L unmarshalled L structure
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public Uuid unmarshalUuidByteArray(byte[] dataset) throws IOException, ClassNotFoundException {
		
		ByteArrayInputStream in = new ByteArrayInputStream(dataset);
		ObjectInputStream ois = null;
		ois = new ObjectInputStream(in);
		Object o = ois.readObject();
		Uuid uuid = (Uuid) o; // TODO: Ensure the type conversion is valid
		in.close();
		if (in != null) {
			ois.close();
		}
		return uuid;
	}
	
	/**
	 * Method responsible for serializing Byte-Array
	 */
	public Uuid marshalUuidByteArray() {
		//TODO: implement Method
		return null;
	}
	
	
	public void convertAllToLittleEndian(){
		uuid = Gatt_CharacteristicUtility.convertToLittleEndian(uuid);
		bleUuid = Gatt_CharacteristicUtility.convertToLittleEndian(bleUuid);
	}
	
	
}
