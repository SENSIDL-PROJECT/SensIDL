import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import com.google.gson.Gson;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
 
/**
 * Data transfer object for Properties
 *
 * @generated
 */
public class Properties {
	
	private static final long serialVersionUID = 1L;
	
	private java.lang.Byte PROPERTY_BROADCAST = 1;
	
	private java.lang.Byte PROPERTY_READ = 2;
	
	private java.lang.Byte PROPERTY_WRITE_NO_RESPONSE = 4;
	
	private java.lang.Byte PROPERTY_WRITE = 8;
	
	private java.lang.Byte PROPERTY_NOTIFY = 16;
	
	private java.lang.Byte PRPERTY_INDICATE = 32;
	
	private java.lang.Byte PROPERTY_SIGNED_WRITE = 64;
	
	private java.lang.Byte PROPERTY_EXTENDED = 128;
	
	/**
	 * Constructor for the Data transfer object
	 */
	public Properties() {
	}
	
	
	/**
	 * @return the property_Broadcast
	 */
	public java.lang.Byte getPropertyBroadcast() {
		return this.PROPERTY_BROADCAST;
	}
	
	// no setter for constant value
	
	/**
	 * @return the property_Read
	 */
	public java.lang.Byte getPropertyRead() {
		return this.PROPERTY_READ;
	}
	
	// no setter for constant value
	
	/**
	 * @return the property_Write_no_response
	 */
	public java.lang.Byte getPropertyWritenoresponse() {
		return this.PROPERTY_WRITE_NO_RESPONSE;
	}
	
	// no setter for constant value
	
	/**
	 * @return the property_Write
	 */
	public java.lang.Byte getPropertyWrite() {
		return this.PROPERTY_WRITE;
	}
	
	// no setter for constant value
	
	/**
	 * @return the property_Notify
	 */
	public java.lang.Byte getPropertyNotify() {
		return this.PROPERTY_NOTIFY;
	}
	
	// no setter for constant value
	
	/**
	 * @return the prperty_Indicate
	 */
	public java.lang.Byte getPrpertyIndicate() {
		return this.PRPERTY_INDICATE;
	}
	
	// no setter for constant value
	
	/**
	 * @return the property_Signed_write
	 */
	public java.lang.Byte getPropertySignedwrite() {
		return this.PROPERTY_SIGNED_WRITE;
	}
	
	// no setter for constant value
	
	/**
	 * @return the property_Extended
	 */
	public java.lang.Byte getPropertyExtended() {
		return this.PROPERTY_EXTENDED;
	}
	
	// no setter for constant value
	
	/**
	 * Alternative method responsible for deserializing the received
	 * JSON-formatted L stage from sensor.
	 * 
	 * @param dataset
	 *            the dataset to unmarshall incoming from sensor side in a JSON
	 *            format
	 * @return L unmarshalled L structure
	 */
	public Properties unmarshalPropertiesJSON(BufferedReader dataset) { 
		
		Gson gson = new Gson();
		BufferedReader br = dataset;
		Properties obj = gson.fromJson(br, Properties.class);
		// use little endianness 
		obj.convertAllToLittleEndian();
		return obj;
	}
	
	/**
	 * Alternative method responsible for serializing JSON
	 * 
	 * @return Json String
	 */
	public String marshalPropertiesJSON() { 
		Gson gson = new Gson();
		// use little endianness
		Properties properties = new Properties();
		return gson.toJson(properties);
	}
	
	/**
	 * Method responsible for deserializing the received byte array
	 * representation of L from sensor.
	 * 
	 * @param dataset
	 *            the dataset to unmarshall incoming from sensor side as a byte
	 *            array
	 * @return L unmarshalled L structure
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public Properties unmarshalPropertiesByteArray(byte[] dataset) throws IOException, ClassNotFoundException {
		
		ByteArrayInputStream in = new ByteArrayInputStream(dataset);
		ObjectInputStream ois = null;
		ois = new ObjectInputStream(in);
		Object o = ois.readObject();
		Properties properties = (Properties) o; // TODO: Ensure the type conversion is valid
		in.close();
		if (in != null) {
			ois.close();
		}
		return properties;
	}
	
	/**
	 * Method responsible for serializing Byte-Array
	 */
	public Properties marshalPropertiesByteArray() {
		//TODO: implement Method
		return null;
	}
	
	
	public void convertAllToLittleEndian(){
		PROPERTY_BROADCAST = Gatt_CharacteristicUtility.convertToLittleEndian(PROPERTY_BROADCAST);
		PROPERTY_READ = Gatt_CharacteristicUtility.convertToLittleEndian(PROPERTY_READ);
		PROPERTY_WRITE_NO_RESPONSE = Gatt_CharacteristicUtility.convertToLittleEndian(PROPERTY_WRITE_NO_RESPONSE);
		PROPERTY_WRITE = Gatt_CharacteristicUtility.convertToLittleEndian(PROPERTY_WRITE);
		PROPERTY_NOTIFY = Gatt_CharacteristicUtility.convertToLittleEndian(PROPERTY_NOTIFY);
		PRPERTY_INDICATE = Gatt_CharacteristicUtility.convertToLittleEndian(PRPERTY_INDICATE);
		PROPERTY_SIGNED_WRITE = Gatt_CharacteristicUtility.convertToLittleEndian(PROPERTY_SIGNED_WRITE);
		PROPERTY_EXTENDED = Gatt_CharacteristicUtility.convertToLittleEndian(PROPERTY_EXTENDED);
	}
	
	
}
