import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import com.google.gson.Gson;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
 
/**
 * Data transfer object for CharacteristicValue
 *
 * @generated
 */
public class CharacteristicValue {
	
	private static final long serialVersionUID = 1L;
	
	private java.lang.Short valueHandle;
	
	/*
	 *0xuuuu , eigther 16 bit Bluetooth UUID or 128bit UUID for chararcteristic *
	 */
	private java.lang.Long uuid;
	
	private java.lang.Long value;
	/*
	 *  Specified by service or implementation *
	 * 
	 * Unit: 
	 */
	private java.lang.Byte charValue_Permission;
	
	
	/*	
	 * 
	 */
	private Uuid uuid;
	
	/**
	 * Constructor for the Data transfer object
	 */
	public CharacteristicValue(java.lang.Short valueHandle, java.lang.Long uuid, java.lang.Long value, java.lang.Byte charValue_Permission, Uuid uuid) {
		this.charValue_Permission = (byte) (charValue_Permission - java.lang.Byte.MAX_VALUE);
		this.valueHandle = (short) (valueHandle - java.lang.Short.MAX_VALUE);
		this.uuid = (long) (uuid - java.lang.Long.MAX_VALUE);
		this.value = (long) (value - java.lang.Long.MAX_VALUE);
		this.uuid = uuid;
	}
	
	/**
	 * empty constructor for the Data transfer object
	 */
	public CharacteristicValue() {
	
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the charValue_Permission
	 */
	public java.lang.Byte getCharValuePermission() {
		return (byte) (this.charValue_Permission + java.lang.Byte.MAX_VALUE);
	}
	
	/**
	 * @param charValue_Permission  
	 *            the charValue_Permission to set
	 */
	public void setCharValuePermission(java.lang.Byte charValue_Permission) {
		
		this.charValue_Permission = (byte) (charValue_Permission - java.lang.Byte.MAX_VALUE);
	} 
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the valueHandle
	 */
	public java.lang.Short getValueHandle() {
		return (short) (this.valueHandle + java.lang.Short.MAX_VALUE);
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @param valueHandle
	 *            the valueHandle to set
	 */
	public void setValueHandle(java.lang.Short valueHandle){
		this.valueHandle = (short) (valueHandle - java.lang.Short.MAX_VALUE);
	} 
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the uuid
	 */
	public java.lang.Long getUuid() {
		return (long) (this.uuid + java.lang.Long.MAX_VALUE);
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @param uuid
	 *            the uuid to set
	 */
	public void setUuid(java.lang.Long uuid){
		this.uuid = (long) (uuid - java.lang.Long.MAX_VALUE);
	} 
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the value
	 */
	public java.lang.Long getValue() {
		return (long) (this.value + java.lang.Long.MAX_VALUE);
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @param value
	 *            the value to set
	 */
	public void setValue(java.lang.Long value){
		this.value = (long) (value - java.lang.Long.MAX_VALUE);
	} 
	
	/**
	 * @return the uuid
	 *
	 */
	public Uuid getUuid() {
		return this.uuid;
	}
	
	/**
	 * @param info
	 *            the uuid to set
	 */
	public void setUuid(Uuid uuid) {
		this.uuid = uuid;
	}
	
	/**
	 * Alternative method responsible for deserializing the received
	 * JSON-formatted L stage from sensor.
	 * 
	 * @param dataset
	 *            the dataset to unmarshall incoming from sensor side in a JSON
	 *            format
	 * @return L unmarshalled L structure
	 */
	public CharacteristicValue unmarshalCharacteristicValueJSON(BufferedReader dataset) { 
		
		Gson gson = new Gson();
		BufferedReader br = dataset;
		CharacteristicValue obj = gson.fromJson(br, CharacteristicValue.class);
		// use little endianness 
		obj.convertAllToLittleEndian();
		return obj;
	}
	
	/**
	 * Alternative method responsible for serializing JSON
	 * 
	 * @return Json String
	 */
	public String marshalCharacteristicValueJSON() { 
		Gson gson = new Gson();
		// use little endianness
		CharacteristicValue characteristicValue = new CharacteristicValue(Gatt_CharacteristicUtility.convertToLittleEndian((short) (this.valueHandle + java.lang.Short.MAX_VALUE)), Gatt_CharacteristicUtility.convertToLittleEndian((long) (this.uuid + java.lang.Long.MAX_VALUE)) , Gatt_CharacteristicUtility.convertToLittleEndian((long) (this.value + java.lang.Long.MAX_VALUE)) , Gatt_CharacteristicUtility.convertToLittleEndian((byte) (this.charValue_Permission + java.lang.Byte.MAX_VALUE)) , convertToLittleEndian(this.uuid));
		return gson.toJson(characteristicValue);
	}
	
	/**
	 * Method responsible for deserializing the received byte array
	 * representation of L from sensor.
	 * 
	 * @param dataset
	 *            the dataset to unmarshall incoming from sensor side as a byte
	 *            array
	 * @return L unmarshalled L structure
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public CharacteristicValue unmarshalCharacteristicValueByteArray(byte[] dataset) throws IOException, ClassNotFoundException {
		
		ByteArrayInputStream in = new ByteArrayInputStream(dataset);
		ObjectInputStream ois = null;
		ois = new ObjectInputStream(in);
		Object o = ois.readObject();
		CharacteristicValue characteristicValue = (CharacteristicValue) o; // TODO: Ensure the type conversion is valid
		in.close();
		if (in != null) {
			ois.close();
		}
		return characteristicValue;
	}
	
	/**
	 * Method responsible for serializing Byte-Array
	 */
	public CharacteristicValue marshalCharacteristicValueByteArray() {
		//TODO: implement Method
		return null;
	}
	
	/**
	 * Converts a big endian Uuid Object into a little endian Uuid Object
	 *	
	 * @param the Uuid Object to convert
	 * @return Uuid the converted Uuid Object
	 *
	 */
	public Uuid convertToLittleEndian(Uuid uuid){
		//TODO: implement Method
		return null;
	}
	
	public void convertAllToLittleEndian(){
		charValue_Permission = Gatt_CharacteristicUtility.convertToLittleEndian(charValue_Permission);
		valueHandle = Gatt_CharacteristicUtility.convertToLittleEndian(valueHandle);
		uuid = Gatt_CharacteristicUtility.convertToLittleEndian(uuid);
		value = Gatt_CharacteristicUtility.convertToLittleEndian(value);
		uuid = convertToLittleEndian(uuid);
	}
	
	
}
