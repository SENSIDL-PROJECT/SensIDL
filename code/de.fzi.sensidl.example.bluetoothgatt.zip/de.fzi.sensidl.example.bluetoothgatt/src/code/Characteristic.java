import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import com.google.gson.Gson;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
 
/**
 * Data transfer object for Characteristic
 *
 * @generated
 */
public class Characteristic {
	
	private static final long serialVersionUID = 1L;
	
	/*
	 *0xNNNN Attribute Handle: 16 bit value assigned by servers to their own attributes, to access the attributes 
	 */
	private java.lang.Short handle;
	
	private java.lang.Long TYPE_UUID = (long) (10243 - java.lang.Long.MAX_VALUE);
	
	/*
	 *Attribute Permissions 
	 */
	private java.lang.Byte permission;
	
	/*
	 * Descriptor_Handle as defined in the descriptor declaration 
	 */
	private java.lang.Short descriptor;
	
	/*	
	 * Attribute Value 
	 */
	private AValue aValue;
	
	/**
	 * Constructor for the Data transfer object
	 */
	public Characteristic(java.lang.Short handle, java.lang.Byte permission, java.lang.Short descriptor, AValue aValue) {
		this.handle = (short) (handle - java.lang.Short.MAX_VALUE);
		this.permission = (byte) (permission - java.lang.Byte.MAX_VALUE);
		this.descriptor = (short) (descriptor - java.lang.Short.MAX_VALUE);
		this.aValue = aValue;
	}
	
	/**
	 * empty constructor for the Data transfer object
	 */
	public Characteristic() {
	
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the handle
	 */
	public java.lang.Short getHandle() {
		return (short) (this.handle + java.lang.Short.MAX_VALUE);
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @param handle
	 *            the handle to set
	 */
	public void setHandle(java.lang.Short handle){
		this.handle = (short) (handle - java.lang.Short.MAX_VALUE);
	} 
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the type_UUID
	 */
	public java.lang.Long getTypeUUID() {
		return (long) (TYPE_UUID + java.lang.Long.MAX_VALUE);
	}
	
	// no setter for constant value
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the permission
	 */
	public java.lang.Byte getPermission() {
		return (byte) (this.permission + java.lang.Byte.MAX_VALUE);
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @param permission
	 *            the permission to set
	 */
	public void setPermission(java.lang.Byte permission){
		this.permission = (byte) (permission - java.lang.Byte.MAX_VALUE);
	} 
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @return the descriptor
	 */
	public java.lang.Short getDescriptor() {
		return (short) (this.descriptor + java.lang.Short.MAX_VALUE);
	}
	
	/**
	 * Java has no option for unsigned data types, so if the data has an 
	 * unsigned data type the value is calculated by subtracting the maximum 
	 * value from the signed data type and adding it again, if it is used.
	 *
	 * @param descriptor
	 *            the descriptor to set
	 */
	public void setDescriptor(java.lang.Short descriptor){
		this.descriptor = (short) (descriptor - java.lang.Short.MAX_VALUE);
	} 
	
	/**
	 * @return the aValue
	 *
	 */
	public AValue getAValue() {
		return this.aValue;
	}
	
	/**
	 * @param info
	 *            the aValue to set
	 */
	public void setAValue(AValue aValue) {
		this.aValue = aValue;
	}
	
	/**
	 * Alternative method responsible for deserializing the received
	 * JSON-formatted L stage from sensor.
	 * 
	 * @param dataset
	 *            the dataset to unmarshall incoming from sensor side in a JSON
	 *            format
	 * @return L unmarshalled L structure
	 */
	public Characteristic unmarshalCharacteristicJSON(BufferedReader dataset) { 
		
		Gson gson = new Gson();
		BufferedReader br = dataset;
		Characteristic obj = gson.fromJson(br, Characteristic.class);
		// use little endianness 
		obj.convertAllToLittleEndian();
		return obj;
	}
	
	/**
	 * Alternative method responsible for serializing JSON
	 * 
	 * @return Json String
	 */
	public String marshalCharacteristicJSON() { 
		Gson gson = new Gson();
		// use little endianness
		Characteristic characteristic = new Characteristic(Gatt_CharacteristicUtility.convertToLittleEndian((short) (this.handle + java.lang.Short.MAX_VALUE)), Gatt_CharacteristicUtility.convertToLittleEndian((byte) (this.permission + java.lang.Byte.MAX_VALUE)) , Gatt_CharacteristicUtility.convertToLittleEndian((short) (this.descriptor + java.lang.Short.MAX_VALUE)) , convertToLittleEndian(this.aValue));
		return gson.toJson(characteristic);
	}
	
	/**
	 * Method responsible for deserializing the received byte array
	 * representation of L from sensor.
	 * 
	 * @param dataset
	 *            the dataset to unmarshall incoming from sensor side as a byte
	 *            array
	 * @return L unmarshalled L structure
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public Characteristic unmarshalCharacteristicByteArray(byte[] dataset) throws IOException, ClassNotFoundException {
		
		ByteArrayInputStream in = new ByteArrayInputStream(dataset);
		ObjectInputStream ois = null;
		ois = new ObjectInputStream(in);
		Object o = ois.readObject();
		Characteristic characteristic = (Characteristic) o; // TODO: Ensure the type conversion is valid
		in.close();
		if (in != null) {
			ois.close();
		}
		return characteristic;
	}
	
	/**
	 * Method responsible for serializing Byte-Array
	 */
	public Characteristic marshalCharacteristicByteArray() {
		//TODO: implement Method
		return null;
	}
	
	/**
	 * Converts a big endian AValue Object into a little endian AValue Object
	 *	
	 * @param the AValue Object to convert
	 * @return AValue the converted AValue Object
	 *
	 */
	public AValue convertToLittleEndian(AValue aValue){
		//TODO: implement Method
		return null;
	}
	
	public void convertAllToLittleEndian(){
		handle = Gatt_CharacteristicUtility.convertToLittleEndian(handle);
		TYPE_UUID = Gatt_CharacteristicUtility.convertToLittleEndian(TYPE_UUID);
		permission = Gatt_CharacteristicUtility.convertToLittleEndian(permission);
		descriptor = Gatt_CharacteristicUtility.convertToLittleEndian(descriptor);
		aValue = convertToLittleEndian(aValue);
	}
	
	
}
